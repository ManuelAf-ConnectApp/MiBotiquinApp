package com.connectapp.presentation.profile

import androidx.compose.foundation.layout.*
import com.connectapp.presentation.component.BrandIcon
import com.connectapp.presentation.component.InformationPanel
import com.connectapp.presentation.component.PrimaryActionButton
import androidx.compose.material.icons.filled.Info
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.connectapp.commonresources.*
import com.connectapp.domain.model.User
import com.connectapp.presentation.profile.component.ProfileInfoItem
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.viewmodel.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    modifier: Modifier = Modifier,
    user: User?,
    onNavigateBack: () -> Unit,
    onNavigateToLogin: () -> Unit
) {
    val viewModel: ProfileViewModel = koinViewModel()
    val state by viewModel.state.collectAsStateWithLifecycle()
    val onIntent = viewModel::onIntent

    // Resolve identity from the active local session; route payloads may be stale.
    val resolvedState = state

    LaunchedEffect(user?.id) {
        onIntent(ProfileIntent.LoadProfile)
    }

    LaunchedEffect(Unit) {
        viewModel.effect.collect { effect ->
            when (effect) {
                ProfileEffect.NavigateBack -> onNavigateBack()
                ProfileEffect.NavigateToLogin -> onNavigateToLogin()
            }
        }
    }
    if (resolvedState.isLoading) {
        Box(
            modifier = modifier
                .fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
    } else {
        var showDeleteConfirmation by remember { mutableStateOf(false) }

        Box(
            modifier = modifier
                .fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            ProfileScreenContent(
                state = resolvedState,
                onLogout = { onIntent(ProfileIntent.LogoutClicked) },
                onDeleteAccount = { showDeleteConfirmation = true },
                onRecovery = { onIntent(ProfileIntent.OpenRecovery) }
            )
        }

        if (state.showRecovery) {
            AlertDialog(
                onDismissRequest = { if (state.recoveryCode == null) onIntent(ProfileIntent.CloseRecovery) },
                title = { Text(stringResource(recovery_code_title)) },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        if (state.recoveryCode != null) {
                            Text(stringResource(recovery_code_saved_warning))
                            Spacer(Modifier.height(Dimen16))
                            state.recoveryCode?.let { code -> SelectionContainer { Text(code) } }
                        } else {
                            Text(stringResource(recovery_code_instruction))
                            Spacer(Modifier.height(Dimen16))
                            OutlinedTextField(
                                value = state.recoveryPassword,
                                onValueChange = { onIntent(ProfileIntent.RecoveryPasswordChanged(it)) },
                                label = { Text(stringResource(label_password)) },
                                singleLine = true, enabled = !state.isRecoveryLoading,
                                visualTransformation = PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                            )
                        }
                        if (state.isRecoveryLoading) CircularProgressIndicator()
                        state.errorMessage?.let { Text(it.asString(), color = MaterialTheme.colorScheme.error) }
                    }
                },
                confirmButton = {
                    TextButton(
                        enabled = !state.isRecoveryLoading && (state.recoveryCode != null || state.recoveryPassword.isNotBlank()),
                        onClick = { onIntent(if (state.recoveryCode != null) ProfileIntent.CloseRecovery else ProfileIntent.GenerateRecovery) }
                    ) { Text(stringResource(if (state.recoveryCode != null) recovery_saved else recovery_generate)) }
                },
                dismissButton = {
                    if (state.recoveryCode == null) TextButton(
                        onClick = { onIntent(ProfileIntent.CloseRecovery) }, enabled = !state.isRecoveryLoading
                    ) { Text(stringResource(button_cancel)) }
                }
            )
        }

        if (showDeleteConfirmation) {
            AlertDialog(
                onDismissRequest = { showDeleteConfirmation = false },
                title = { Text(stringResource(delete_account_confirmation_title)) },
                text = { Text(stringResource(delete_account_confirmation_message)) },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showDeleteConfirmation = false
                            onIntent(ProfileIntent.DeleteAccountClicked)
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text(stringResource(button_delete))
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteConfirmation = false }) {
                        Text(stringResource(button_cancel))
                    }
                }
            )
        }
    }

}

@Composable
private fun ProfileScreenContent(
    state: ProfileState,
    onLogout: () -> Unit,
    onDeleteAccount: () -> Unit,
    onRecovery: () -> Unit
) {
    Column(
        modifier = Modifier
            .widthIn(max = Dimen560)
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(Dimen24),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        state.user?.let { user ->
            BrandIcon(Icons.Default.Person, large = true)
            Spacer(modifier = Modifier.height(Dimen24))

            ProfileInfoItem(
                icon = Icons.Default.Person,
                label = stringResource(label_name),
                value = "${user.firstName} ${user.lastName}".trim()
            )

            Spacer(modifier = Modifier.height(Dimen16))

            ProfileInfoItem(
                icon = Icons.Default.Email,
                label = stringResource(label_email),
                value = user.email
            )

            Spacer(modifier = Modifier.height(Dimen24))
            PrimaryActionButton(stringResource(recovery_code_title), onRecovery)
            Spacer(Modifier.height(Dimen16))
            InformationPanel(stringResource(profile_recovery_subtitle), Icons.Default.Info)
            Spacer(Modifier.height(Dimen8))

            Button(
                onClick = onLogout,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                )
            ) {
                Text(stringResource(logout))
            }

            Spacer(modifier = Modifier.height(Dimen8))

            TextButton(
                onClick = onDeleteAccount,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.textButtonColors(
                    contentColor = MaterialTheme.colorScheme.error
                )
            ) {
                Text(stringResource(delete_account))
            }
        } ?: Text(stringResource(error_user_not_found))

        state.errorMessage?.let { errorMessage ->
            Spacer(modifier = Modifier.height(Dimen8))
            Text(
                text = errorMessage.asString(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}
