package com.connectapp.presentation.forgot_password

import androidx.compose.foundation.layout.*
import com.connectapp.presentation.component.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.material3.*
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.connectapp.commonresources.*
import org.jetbrains.compose.resources.stringResource
import org.koin.compose.viewmodel.koinViewModel

@Composable
fun ForgotPasswordScreen(
    modifier: Modifier = Modifier,
    onNavigateBack: () -> Unit
) {
    val viewModel: ForgotPasswordViewModel = koinViewModel()
    val state by viewModel.state.collectAsStateWithLifecycle()
    val onIntent = viewModel::onIntent

    DisposableEffect(viewModel) {
        onDispose { onIntent(ForgotPasswordIntent.ClearForm) }
    }

    LaunchedEffect(Unit) {
        viewModel.effect.collect { effect ->
            when (effect) {
                ForgotPasswordEffect.NavigateToLogin -> onNavigateBack()
            }
        }
    }

    ForgotPasswordScreenContent(modifier, state, onIntent)
}

@Composable
internal fun ForgotPasswordScreenContent(
    modifier: Modifier = Modifier, state: ForgotPasswordState, onIntent: (ForgotPasswordIntent) -> Unit
) {
    var passwordVisible by remember { mutableStateOf(false) }
    var confirmationVisible by remember { mutableStateOf(false) }
    AuthLayout(modifier) {
        SectionIntro(stringResource(forgot_password_title), stringResource(recovery_subtitle), Icons.Default.Key)
        if (state.isReset) {
            InformationPanel(stringResource(forgot_password_success), Icons.Default.CheckCircle)
        } else {
            AppTextField(state.email, { onIntent(ForgotPasswordIntent.EmailChanged(it)) }, stringResource(label_email),
                keyboardType = KeyboardType.Email, trailingIcon = Icons.Default.Email, enabled = !state.isLoading)
            AppTextField(state.code, { onIntent(ForgotPasswordIntent.CodeChanged(it)) }, stringResource(recovery_code_title),
                enabled = !state.isLoading)
            PasswordField(state.password, { onIntent(ForgotPasswordIntent.PasswordChanged(it)) }, stringResource(recovery_new_password),
                passwordVisible, { passwordVisible = !passwordVisible }, enabled = !state.isLoading)
            PasswordField(state.confirmPassword, { onIntent(ForgotPasswordIntent.ConfirmPasswordChanged(it)) }, stringResource(label_confirm_password),
                confirmationVisible, { confirmationVisible = !confirmationVisible }, enabled = !state.isLoading)
            state.errorMessage?.let {
                Text(it.asString(), color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
            }
            PrimaryActionButton(stringResource(recovery_reset), { onIntent(ForgotPasswordIntent.ResetClicked) }, busy = state.isLoading)
            InformationPanel(stringResource(forgot_password_instruction), Icons.Default.Info)
        }
        TextButton(onClick = { onIntent(ForgotPasswordIntent.BackToLoginClicked) },
            modifier = Modifier.align(Alignment.CenterHorizontally), enabled = !state.isLoading) {
            Text(stringResource(button_back_to_login))
        }
    }
}
