package com.connectapp.presentation.profile

sealed interface ProfileIntent {
    data object OpenRecovery : ProfileIntent
    data class RecoveryPasswordChanged(val password: String) : ProfileIntent
    data object GenerateRecovery : ProfileIntent
    data object CloseRecovery : ProfileIntent
    data object LogoutClicked : ProfileIntent
    data object DeleteAccountClicked : ProfileIntent
    data object BackClicked : ProfileIntent
    data object LoadProfile : ProfileIntent
}
