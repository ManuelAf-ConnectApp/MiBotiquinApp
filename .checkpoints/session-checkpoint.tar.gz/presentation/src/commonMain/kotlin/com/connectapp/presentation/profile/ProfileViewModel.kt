package com.connectapp.presentation.profile

import com.connectapp.domain.usecase.IssueRecoveryCodeUseCase
import com.connectapp.domain.usecase.GetCurrentUserUseCase
import com.connectapp.domain.usecase.LogoutUseCase
import com.connectapp.domain.usecase.DeleteAccountUseCase
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.connectapp.presentation.util.asUiText
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job

class ProfileViewModel(
    private val getCurrentUserUseCase: GetCurrentUserUseCase,
    private val logoutUseCase: LogoutUseCase,
    private val deleteAccountUseCase: DeleteAccountUseCase,
    private val issueRecoveryCode: IssueRecoveryCodeUseCase
) : ViewModel() {

    private var recoveryJob: Job? = null
    private val _state = MutableStateFlow(ProfileState())
    val state: StateFlow<ProfileState> = _state.asStateFlow()

    private val _effect = MutableSharedFlow<ProfileEffect>()
    val effect: SharedFlow<ProfileEffect> = _effect.asSharedFlow()

    fun onIntent(intent: ProfileIntent) {
        when (intent) {
            ProfileIntent.OpenRecovery -> _state.update { it.copy(showRecovery = true, errorMessage = null) }
            is ProfileIntent.RecoveryPasswordChanged -> _state.update { it.copy(recoveryPassword = intent.password) }
            ProfileIntent.GenerateRecovery -> generateRecovery()
            ProfileIntent.CloseRecovery -> {
                if (!_state.value.isRecoveryLoading) _state.update {
                    it.copy(showRecovery = false, recoveryPassword = "", recoveryCode = null, errorMessage = null)
                }
            }
            ProfileIntent.BackClicked -> {
                viewModelScope.launch {
                    _effect.emit(ProfileEffect.NavigateBack)
                }
            }

            ProfileIntent.LogoutClicked -> {
                logout()
            }

            ProfileIntent.DeleteAccountClicked -> {
                deleteAccount()
            }

            ProfileIntent.LoadProfile -> {
                loadProfile()
            }
        }
    }

    private fun generateRecovery() {
        val form = _state.value
        if (form.isRecoveryLoading || form.recoveryCode != null) return
        _state.update { it.copy(isRecoveryLoading = true, errorMessage = null) }
        recoveryJob = viewModelScope.launch {
            issueRecoveryCode(form.recoveryPassword)
                .onSuccess { code -> _state.update {
                    it.copy(isRecoveryLoading = false, recoveryPassword = "", recoveryCode = code)
                } }
                .onFailure { error -> _state.update {
                    it.copy(isRecoveryLoading = false, recoveryPassword = "", errorMessage = error.asUiText())
                } }
        }
    }

    private fun loadProfile() {
        recoveryJob?.cancel()
        viewModelScope.launch {
            _state.value = ProfileState(isLoading = true)
            getCurrentUserUseCase()
                .onSuccess { user ->
                    _state.update {
                        it.copy(
                            isLoading = false,
                            user = user
                        )
                    }
                }
                .onFailure { exception ->
                    _state.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = exception.asUiText()
                        )
                    }
                }
        }
    }

    private fun logout() {
        recoveryJob?.cancel()
        viewModelScope.launch {
            _state.value = ProfileState(isLoading = true)
            logoutUseCase().onSuccess {
                _state.update { it.copy(isLoading = false) }
                _effect.emit(ProfileEffect.NavigateToLogin)
            }.onFailure { exception ->
                _state.update { it.copy(isLoading = false, errorMessage = exception.asUiText()) }
            }
        }
    }

    // Borra la cuenta de la sesión activa: el repositorio la resuelve por sí mismo, así un
    // estado obsoleto de este ViewModel (compartido entre sesiones) no puede borrar otra cuenta.
    private fun deleteAccount() {
        recoveryJob?.cancel()
        viewModelScope.launch {
            _state.value = ProfileState(isLoading = true)
            deleteAccountUseCase().onSuccess {
                _state.update { it.copy(isLoading = false) }
                _effect.emit(ProfileEffect.NavigateToLogin)
            }.onFailure { exception ->
                _state.update { it.copy(isLoading = false, errorMessage = exception.asUiText()) }
            }
        }
    }
}
